//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// Kdtree.h
//
// Code generation for function 'Kdtree'
//

#ifndef KDTREE_H
#define KDTREE_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Type Definitions
namespace coder {
namespace vision {
namespace internal {
namespace codegen {
class Kdtree {
};

} // namespace codegen
} // namespace internal
} // namespace vision
} // namespace coder

#endif
// End of code generation (Kdtree.h)
