//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// proc_mapping_data.cpp
//
// Code generation for function 'proc_mapping_data'
//

// Include files
#include "proc_mapping_data.h"
#include "rt_nonfinite.h"
#include <string.h>

// Variable Definitions
double freq;

bool freq_not_empty;

bool newSonarMsg;

bool bundleStarted;

bool isInitialized_proc_mapping{false};

// End of code generation (proc_mapping_data.cpp)
