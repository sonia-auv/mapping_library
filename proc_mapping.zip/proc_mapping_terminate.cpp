//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// proc_mapping_terminate.cpp
//
// Code generation for function 'proc_mapping_terminate'
//

// Include files
#include "proc_mapping_terminate.h"
#include "proc_mapping_data.h"
#include "rt_nonfinite.h"
#include <string.h>

// Function Definitions
void proc_mapping_terminate()
{
  isInitialized_proc_mapping = false;
}

// End of code generation (proc_mapping_terminate.cpp)
