//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// Subscriber.cpp
//
// Code generation for function 'Subscriber'
//

// Include files
#include "Subscriber.h"
#include "geometry_msgs_PoseStruct.h"
#include "proc_mapping_data.h"
#include "proc_mapping_types.h"
#include "rt_nonfinite.h"
#include "sensor_msgs_PointCloud2Struct.h"
#include "std_msgs_BoolStruct.h"
#include "coder_array.h"
#include "mlroscpp_sub.h"
#include <stdio.h>
#include <string.h>

// Function Definitions
namespace coder {
namespace ros {
void Subscriber::callback()
{
  MessageCount = get_MessageCount() + 1.0;
  if (IsInitialized) {
    bundleStarted = MsgStruct.Data;
    //  Initial variables
    //  SET
    //  Initial variables
    //  GET
    if (bundleStarted) {
      printf("INFO : proc mapping : Bundle record started \n");
      fflush(stdout);
    } else {
      printf("INFO : proc mapping : Bundle record stopped \n");
      fflush(stdout);
    }
  }
}

void b_Subscriber::callback()
{
  MessageCount = get_MessageCount() + 1.0;
}

void c_Subscriber::callback()
{
  MessageCount = get_MessageCount() + 1.0;
  if (IsInitialized) {
    //  Initial variables
    //  SET
    newSonarMsg = true;
  }
}

double Subscriber::get_MessageCount() const
{
  return MessageCount;
}

double b_Subscriber::get_MessageCount() const
{
  return MessageCount;
}

double c_Subscriber::get_MessageCount() const
{
  return MessageCount;
}

void c_Subscriber::get_LatestMessage(
    unsigned int *lastSubMsg_Height, unsigned int *lastSubMsg_Width,
    ::coder::array<sensor_msgs_PointFieldStruct_T, 1U> &lastSubMsg_Fields,
    unsigned int *lastSubMsg_PointStep,
    ::coder::array<unsigned char, 1U> &lastSubMsg_Data) const
{
  int loop_ub;
  MATLABSUBSCRIBER_lock(SubscriberHelper);
  lastSubMsg_Fields.set_size(MsgStruct.Fields.size(0));
  loop_ub = MsgStruct.Fields.size(0);
  for (int i{0}; i < loop_ub; i++) {
    lastSubMsg_Fields[i] = MsgStruct.Fields[i];
  }
  lastSubMsg_Data.set_size(MsgStruct.Data.size(0));
  loop_ub = MsgStruct.Data.size(0);
  for (int i{0}; i < loop_ub; i++) {
    lastSubMsg_Data[i] = MsgStruct.Data[i];
  }
  MATLABSUBSCRIBER_unlock(SubscriberHelper);
  *lastSubMsg_Height = MsgStruct.Height;
  *lastSubMsg_Width = MsgStruct.Width;
  *lastSubMsg_PointStep = MsgStruct.PointStep;
}

void b_Subscriber::get_LatestMessage(double *lastSubMsg_Position_X,
                                     double *lastSubMsg_Position_Y,
                                     double *lastSubMsg_Position_Z,
                                     double *lastSubMsg_Orientation_X,
                                     double *lastSubMsg_Orientation_Y,
                                     double *lastSubMsg_Orientation_Z,
                                     double *lastSubMsg_Orientation_W) const
{
  MATLABSUBSCRIBER_lock(SubscriberHelper);
  *lastSubMsg_Position_X = MsgStruct.Position.X;
  *lastSubMsg_Position_Y = MsgStruct.Position.Y;
  *lastSubMsg_Position_Z = MsgStruct.Position.Z;
  *lastSubMsg_Orientation_X = MsgStruct.Orientation.X;
  *lastSubMsg_Orientation_Y = MsgStruct.Orientation.Y;
  *lastSubMsg_Orientation_Z = MsgStruct.Orientation.Z;
  *lastSubMsg_Orientation_W = MsgStruct.Orientation.W;
  MATLABSUBSCRIBER_unlock(SubscriberHelper);
}

Subscriber *Subscriber::init()
{
  static const char topic[24]{'/', 'p', 'r', 'o', 'c', '_', 'm', 'a',
                              'p', 'p', 'i', 'n', 'g', '/', 's', 't',
                              'a', 'r', 't', '_', 's', 't', 'o', 'p'};
  Subscriber *obj;
  obj = this;
  obj->IsInitialized = false;
  for (int i{0}; i < 24; i++) {
    obj->TopicName[i] = topic[i];
  }
  obj->BufferSize = 1.0;
  obj->MessageCount = 0.0;
  obj->MsgStruct = std_msgs_BoolStruct();
  auto structPtr = (&obj->MsgStruct);
  obj->SubscriberHelper =
      std::unique_ptr<MATLABSubscriber<std_msgs::Bool, std_msgs_BoolStruct_T>>(
          new MATLABSubscriber<std_msgs::Bool, std_msgs_BoolStruct_T>(
              structPtr, [this] { this->callback(); })); //();
  MATLABSUBSCRIBER_createSubscriber(obj->SubscriberHelper, &obj->TopicName[0],
                                    24.0, obj->BufferSize);
  obj->callback();
  obj->IsInitialized = true;
  return obj;
}

b_Subscriber *b_Subscriber::init()
{
  static const char topic[18]{'/', 'p', 'r', 'o', 'c', '_', 'n', 'a', 'v',
                              '/', 'a', 'u', 'v', '_', 'p', 'o', 's', 'e'};
  b_Subscriber *obj;
  obj = this;
  for (int i{0}; i < 18; i++) {
    obj->TopicName[i] = topic[i];
  }
  obj->BufferSize = 1.0;
  obj->MessageCount = 0.0;
  geometry_msgs_PoseStruct(&obj->MsgStruct);
  auto structPtr = (&obj->MsgStruct);
  obj->SubscriberHelper = std::unique_ptr<
      MATLABSubscriber<geometry_msgs::Pose, geometry_msgs_PoseStruct_T>>(
      new MATLABSubscriber<geometry_msgs::Pose, geometry_msgs_PoseStruct_T>(
          structPtr, [this] { this->callback(); })); //();
  MATLABSUBSCRIBER_createSubscriber(obj->SubscriberHelper, &obj->TopicName[0],
                                    18.0, obj->BufferSize);
  obj->callback();
  return obj;
}

c_Subscriber *c_Subscriber::init()
{
  static const char topic[28]{'/', 'p', 'r', 'o', 'v', 'i', 'd', 'e', 'r', '_',
                              's', 'o', 'n', 'a', 'r', '/', 'p', 'o', 'i', 'n',
                              't', '_', 'c', 'l', 'o', 'u', 'd', '2'};
  c_Subscriber *obj;
  obj = this;
  obj->IsInitialized = false;
  for (int i{0}; i < 28; i++) {
    obj->TopicName[i] = topic[i];
  }
  obj->BufferSize = 1.0;
  obj->MessageCount = 0.0;
  sensor_msgs_PointCloud2Struct(&obj->MsgStruct);
  auto structPtr = (&obj->MsgStruct);
  obj->SubscriberHelper =
      std::unique_ptr<MATLABSubscriber<sensor_msgs::PointCloud2,
                                       sensor_msgs_PointCloud2Struct_T>>(
          new MATLABSubscriber<sensor_msgs::PointCloud2,
                               sensor_msgs_PointCloud2Struct_T>(
              structPtr, [this] { this->callback(); })); //();
  MATLABSUBSCRIBER_createSubscriber(obj->SubscriberHelper, &obj->TopicName[0],
                                    28.0, obj->BufferSize);
  obj->callback();
  obj->IsInitialized = true;
  return obj;
}

} // namespace ros
} // namespace coder

// End of code generation (Subscriber.cpp)
