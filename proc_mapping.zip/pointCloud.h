//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// pointCloud.h
//
// Code generation for function 'pointCloud'
//

#ifndef POINTCLOUD_H
#define POINTCLOUD_H

// Include files
#include "Kdtree.h"
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Type Definitions
namespace coder {
class pointCloud {
public:
  void matlabCodegenDestructor();
  ~pointCloud();
  pointCloud();
  bool matlabCodegenIsDeleted;
  double Location[3];
  array<unsigned char, 2U> Color;
  array<double, 2U> Normal;
  array<double, 2U> Intensity;
  vision::internal::codegen::Kdtree *b_Kdtree;
  vision::internal::codegen::Kdtree _pobj0;
};

class b_pointCloud {
public:
  void matlabCodegenDestructor();
  ~b_pointCloud();
  b_pointCloud();
  bool matlabCodegenIsDeleted;
  array<double, 2U> Location;
  array<unsigned char, 2U> Color;
  array<double, 2U> Normal;
  array<double, 1U> Intensity;
  vision::internal::codegen::Kdtree *b_Kdtree;
  vision::internal::codegen::Kdtree _pobj0;
};

} // namespace coder

#endif
// End of code generation (pointCloud.h)
