//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// std_msgs_HeaderStruct.h
//
// Code generation for function 'std_msgs_HeaderStruct'
//

#ifndef STD_MSGS_HEADERSTRUCT_H
#define STD_MSGS_HEADERSTRUCT_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
struct std_msgs_HeaderStruct_T;

// Function Declarations
void std_msgs_HeaderStruct(std_msgs_HeaderStruct_T *msg);

#endif
// End of code generation (std_msgs_HeaderStruct.h)
