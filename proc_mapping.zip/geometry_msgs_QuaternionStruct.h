//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// geometry_msgs_QuaternionStruct.h
//
// Code generation for function 'geometry_msgs_QuaternionStruct'
//

#ifndef GEOMETRY_MSGS_QUATERNIONSTRUCT_H
#define GEOMETRY_MSGS_QUATERNIONSTRUCT_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
struct geometry_msgs_QuaternionStruct_T;

// Function Declarations
geometry_msgs_QuaternionStruct_T geometry_msgs_QuaternionStruct();

#endif
// End of code generation (geometry_msgs_QuaternionStruct.h)
