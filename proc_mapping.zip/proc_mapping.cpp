//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// proc_mapping.cpp
//
// Code generation for function 'proc_mapping'
//

// Include files
#include "proc_mapping.h"
#include "Kdtree.h"
#include "PointCloudBundler.h"
#include "Rate.h"
#include "Subscriber.h"
#include "pointCloud.h"
#include "proc_mapping_data.h"
#include "proc_mapping_initialize.h"
#include "proc_mapping_types.h"
#include "rosReadField.h"
#include "rosReadXYZ.h"
#include "rt_nonfinite.h"
#include "svd.h"
#include "tic.h"
#include "toc.h"
#include "coder_array.h"
#include "coder_posix_time.h"
#include "mlroscpp_rate.h"
#include <cmath>
#include <stdio.h>
#include <string.h>

// Function Declarations
static int div_nzp_s32_floor(int numerator, int denominator);

// Function Definitions
static int div_nzp_s32_floor(int numerator, int denominator)
{
  unsigned int absDenominator;
  unsigned int absNumerator;
  int quotient;
  unsigned int tempAbsQuotient;
  bool quotientNeedsNegation;
  if (numerator < 0) {
    absNumerator = ~static_cast<unsigned int>(numerator) + 1U;
  } else {
    absNumerator = static_cast<unsigned int>(numerator);
  }
  if (denominator < 0) {
    absDenominator = ~static_cast<unsigned int>(denominator) + 1U;
  } else {
    absDenominator = static_cast<unsigned int>(denominator);
  }
  quotientNeedsNegation = ((numerator < 0) != (denominator < 0));
  tempAbsQuotient = absNumerator / absDenominator;
  if (quotientNeedsNegation) {
    absNumerator %= absDenominator;
    if (absNumerator > 0U) {
      tempAbsQuotient++;
    }
    quotient = -static_cast<int>(tempAbsQuotient);
  } else {
    quotient = static_cast<int>(tempAbsQuotient);
  }
  return quotient;
}

void proc_mapping()
{
  PointCloudBundler bundler;
  coder::b_pointCloud ptCloud;
  coder::pointCloud *b_this;
  coder::ros::Rate r;
  coder::ros::Subscriber *sub;
  coder::ros::b_Subscriber *b_sub;
  coder::ros::c_Subscriber *c_sub;
  coder::array<sensor_msgs_PointFieldStruct_T, 1U> sonarMsg_Fields;
  coder::array<double, 2U> b_bundler;
  coder::array<double, 2U> c_xyzi;
  coder::array<double, 2U> r2;
  coder::array<double, 2U> xyzi;
  coder::array<double, 1U> b_xyzi;
  coder::array<double, 1U> v;
  coder::array<float, 2U> b_r;
  coder::array<float, 2U> r1;
  coder::array<unsigned char, 1U> sonarMsg_Data;
  coder::array<bool, 1U> rowsToDelete;
  coder::array<bool, 1U> x;
  double absxk;
  double poseMsg_Orientation_Y;
  double poseMsg_Orientation_Z;
  double poseMsg_Position_X;
  double poseMsg_Position_Y;
  double poseMsg_Position_Z;
  double scale;
  double t11;
  double t12;
  double t13;
  double t17;
  double t18;
  double t19;
  double t20;
  double t21;
  double t23;
  double t7;
  double t8;
  int i;
  unsigned int sonarMsg_Height;
  unsigned int sonarMsg_PointStep;
  unsigned int sonarMsg_Width;
  if (!isInitialized_proc_mapping) {
    proc_mapping_initialize();
  }
  //  Variables
  r.init();
  //  Proc_mapping startup
  bundler.bigCloud.matlabCodegenIsDeleted = true;
  bundler.matlabCodegenIsDeleted = true;
  ptCloud.matlabCodegenIsDeleted = true;
  //         %% ROS Spin
  MATLABRate_reset(r.RateHelper);
  coder::tic(&scale, &absxk);
  printf("INFO : proc mapping : Node is started. \n");
  fflush(stdout);
  printf("INFO : proc mapping : Wait for point cloud. \n");
  fflush(stdout);
  //         %% PointCloudBundler Constructor
  b_this = &bundler.bigCloud;
  b_this->Location[0] = 0.0;
  b_this->Location[1] = 0.0;
  b_this->Location[2] = 0.0;
  b_this->Color.set_size(0, 0);
  b_this->Normal.set_size(0, 0);
  b_this->Intensity.set_size(1, 1);
  b_this->Intensity[0] = 0.0;
  b_this->b_Kdtree = &b_this->_pobj0;
  b_this->matlabCodegenIsDeleted = false;
  bundler.bundle.set_size(3, 4);
  for (i = 0; i < 12; i++) {
    bundler.bundle[i] = 0.0;
  }
  bundler.bundle.set_size(1, 4);
  bundler.bundle[0] = 0.0;
  bundler.bundle[1] = 0.0;
  bundler.bundle[2] = 0.0;
  bundler.bundle[3] = 0.0;
  //  Subscribers
  sub = bundler._pobj2.init();
  bundler.startStopSub = sub;
  b_sub = bundler._pobj1.init();
  bundler.poseSub = b_sub;
  c_sub = bundler._pobj0.init();
  bundler.sonarSub = c_sub;
  bundler.lastBundleState = false;
  bundler.matlabCodegenIsDeleted = false;
  while (1) {
    //         %% Step function
    if (bundler.lastBundleState && (!bundleStarted)) {
      int m;
      //  Initial variables
      //  GET
      //  Record finished.
      bundler.lastBundleState = false;
      printf("INFO : proc mapping : Not bundling. \n");
      fflush(stdout);
      ptCloud.matlabCodegenDestructor();
      //         %% Getters / Setters
      m = bundler.bundle.size(0);
      ptCloud.Location.set_size(m, 3);
      for (i = 0; i < 3; i++) {
        for (int i1{0}; i1 < m; i1++) {
          ptCloud.Location[i1 + ptCloud.Location.size(0) * i] =
              bundler.bundle[i1 + bundler.bundle.size(0) * i];
        }
      }
      //         %% Getters / Setters
      m = bundler.bundle.size(0);
      v.set_size(m);
      for (i = 0; i < m; i++) {
        v[i] = bundler.bundle[i + bundler.bundle.size(0) * 3];
      }
      ptCloud.Color.set_size(0, 0);
      ptCloud.Normal.set_size(0, 0);
      ptCloud.Intensity.set_size(v.size(0));
      m = v.size(0);
      for (i = 0; i < m; i++) {
        ptCloud.Intensity[i] = v[i];
      }
      ptCloud.b_Kdtree = &ptCloud._pobj0;
      ptCloud.matlabCodegenIsDeleted = false;
    } else {
      bool VECTOR_INPUT_AND_P_IS_NUMERIC;
      //  Recording or waiting.
      //  Initial variables
      //  GET
      VECTOR_INPUT_AND_P_IS_NUMERIC = newSonarMsg;
      if (VECTOR_INPUT_AND_P_IS_NUMERIC && bundleStarted) {
        double t;
        double t9;
        int i1;
        int i2;
        int m;
        bool MATRIX_INPUT_AND_P_IS_TWO;
        //  Initial variables
        //  GET
        bundler.sonarSub->get_LatestMessage(&sonarMsg_Height, &sonarMsg_Width,
                                            sonarMsg_Fields,
                                            &sonarMsg_PointStep, sonarMsg_Data);
        bundler.poseSub->get_LatestMessage(
            &poseMsg_Position_X, &poseMsg_Position_Y, &poseMsg_Position_Z, &t12,
            &poseMsg_Orientation_Y, &poseMsg_Orientation_Z, &t11);
        //         %% Adding to the point cloud.
        printf("INFO : proc mapping : Append to point cloud. \n");
        fflush(stdout);
        //  scan = rosReadLidarScan(sonarMsg);
        //  Getting the sub pose.
        printf("INFO : proc mapping : Pose received. \n");
        fflush(stdout);
        xyzi.set_size(static_cast<int>(sonarMsg_Width), 4);
        m = static_cast<int>(sonarMsg_Width) << 2;
        for (i = 0; i < m; i++) {
          xyzi[i] = 0.0;
        }
        coder::rosReadXYZ(sonarMsg_Height, sonarMsg_Width, sonarMsg_Fields,
                          sonarMsg_PointStep, sonarMsg_Data, b_r);
        m = b_r.size(0);
        for (i = 0; i < 3; i++) {
          for (i1 = 0; i1 < m; i1++) {
            xyzi[i1 + xyzi.size(0) * i] = b_r[i1 + b_r.size(0) * i];
          }
        }
        //  Temporary swap.
        m = xyzi.size(0);
        v.set_size(xyzi.size(0));
        for (i = 0; i < m; i++) {
          v[i] = xyzi[i];
        }
        m = xyzi.size(0) - 1;
        b_xyzi.set_size(xyzi.size(0));
        for (i = 0; i <= m; i++) {
          b_xyzi[i] = xyzi[i + xyzi.size(0)];
        }
        m = b_xyzi.size(0);
        for (i = 0; i < m; i++) {
          xyzi[i] = b_xyzi[i];
        }
        m = v.size(0);
        for (i = 0; i < m; i++) {
          xyzi[i + xyzi.size(0)] = v[i];
        }
        coder::rosReadField(sonarMsg_Height, sonarMsg_Width, sonarMsg_Fields,
                            sonarMsg_PointStep, sonarMsg_Data, r1);
        r2.set_size(r1.size(0), r1.size(1));
        m = r1.size(0) * r1.size(1);
        for (i = 0; i < m; i++) {
          r2[i] = r1[i];
        }
        m = xyzi.size(0);
        for (i = 0; i < m; i++) {
          xyzi[i + xyzi.size(0) * 3] = r2[i];
        }
        VECTOR_INPUT_AND_P_IS_NUMERIC = false;
        MATRIX_INPUT_AND_P_IS_TWO = false;
        if (xyzi.size(0) == 1) {
          VECTOR_INPUT_AND_P_IS_NUMERIC = true;
        } else {
          MATRIX_INPUT_AND_P_IS_TWO = true;
        }
        if (xyzi.size(0) == 0) {
          t9 = 0.0;
        } else if (MATRIX_INPUT_AND_P_IS_TWO) {
          m = xyzi.size(0) - 1;
          t9 = 0.0;
          for (int j{0}; j < 3; j++) {
            for (i = 0; i <= m; i++) {
              scale = std::abs(xyzi[i + xyzi.size(0) * j]);
              if (std::isnan(scale) || (scale > t9)) {
                t9 = scale;
              }
            }
          }
          if ((!std::isinf(t9)) && (!std::isnan(t9))) {
            m = xyzi.size(0);
            c_xyzi.set_size(xyzi.size(0), 3);
            for (i = 0; i < 3; i++) {
              for (i1 = 0; i1 < m; i1++) {
                c_xyzi[i1 + c_xyzi.size(0) * i] = xyzi[i1 + xyzi.size(0) * i];
              }
            }
            coder::internal::svd(c_xyzi, v);
            t9 = v[0];
          }
        } else if (VECTOR_INPUT_AND_P_IS_NUMERIC) {
          m = xyzi.size(0) * 3;
          t9 = 0.0;
          if (m >= 1) {
            if (m == 1) {
              t9 = std::abs(xyzi[0]);
            } else {
              scale = 3.3121686421112381E-170;
              i = xyzi.size(0);
              for (i2 = 0; i2 < m; i2++) {
                absxk = std::abs(
                    xyzi[i2 % i + xyzi.size(0) * div_nzp_s32_floor(i2, i)]);
                if (absxk > scale) {
                  t = scale / absxk;
                  t9 = t9 * t * t + 1.0;
                  scale = absxk;
                } else {
                  t = absxk / scale;
                  t9 += t * t;
                }
              }
              t9 = scale * std::sqrt(t9);
            }
          }
        } else {
          t9 = rtNaN;
        }
        VECTOR_INPUT_AND_P_IS_NUMERIC = (t9 > 5.0);
        m = xyzi.size(0);
        x.set_size(xyzi.size(0));
        for (i = 0; i < m; i++) {
          x[i] = ((xyzi[i + xyzi.size(0) * 3] < 0.07) &&
                  VECTOR_INPUT_AND_P_IS_NUMERIC);
        }
        rowsToDelete.set_size(x.size(0));
        m = x.size(0);
        for (i = 0; i < m; i++) {
          rowsToDelete[i] = false;
        }
        m = x.size(0);
        i1 = 0;
        i2 = 0;
        for (int j{0}; j < m; j++) {
          bool exitg1;
          i1++;
          i2++;
          i = i1;
          exitg1 = false;
          while ((!exitg1) && ((m > 0) && (i <= i2))) {
            if (x[i - 1]) {
              rowsToDelete[j] = true;
              exitg1 = true;
            } else {
              i += m;
            }
          }
        }
        i1 = xyzi.size(0);
        m = 0;
        i = rowsToDelete.size(0);
        for (i2 = 0; i2 < i; i2++) {
          m += rowsToDelete[i2];
        }
        m = xyzi.size(0) - m;
        i = 0;
        for (i2 = 0; i2 < i1; i2++) {
          if ((i2 + 1 > rowsToDelete.size(0)) || (!rowsToDelete[i2])) {
            xyzi[i] = xyzi[i2];
            xyzi[i + xyzi.size(0)] = xyzi[i2 + xyzi.size(0)];
            xyzi[i + xyzi.size(0) * 2] = xyzi[i2 + xyzi.size(0) * 2];
            xyzi[i + xyzi.size(0) * 3] = xyzi[i2 + xyzi.size(0) * 3];
            i++;
          }
        }
        if (m < 1) {
          m = 0;
        }
        for (i = 0; i < 4; i++) {
          for (i1 = 0; i1 < m; i1++) {
            xyzi[i1 + m * i] = xyzi[i1 + xyzi.size(0) * i];
          }
        }
        xyzi.set_size(m, 4);
        // xyzPoints = zeros([size(xyzi, 1), 3]);
        if (m - 1 >= 0) {
          scale = t12 * poseMsg_Orientation_Y * 2.0;
          t = t12 * poseMsg_Orientation_Z * 2.0;
          t7 = poseMsg_Orientation_Y * poseMsg_Orientation_Z * 2.0;
          t8 = t11 * t12 * 2.0;
          t9 = t11 * poseMsg_Orientation_Y * 2.0;
          absxk = t11 * poseMsg_Orientation_Z * 2.0;
          t11 = t12 * t12 * 2.0;
          t12 = poseMsg_Orientation_Y * poseMsg_Orientation_Y * 2.0;
          t13 = poseMsg_Orientation_Z * poseMsg_Orientation_Z * 2.0;
          t17 = scale + absxk;
          t18 = t + t9;
          t19 = t7 + t8;
          t20 = scale + -absxk;
          t21 = t + -t9;
          t8 = t7 + -t8;
          t23 = (t11 + t12) - 1.0;
          t7 = (t11 + t13) - 1.0;
          t13 = (t12 + t13) - 1.0;
        }
        for (i = 0; i < m; i++) {
          scale = xyzi[i];
          absxk = xyzi[i + xyzi.size(0)];
          // sonar2NED
          //     OUT1 = sonar2NED(IN1,IN2,IN3,IN4)
          //     This function was generated by the Symbolic Math Toolbox
          //     version 9.1. 11-May-2022 11:36:02
          xyzi[i] = (((((poseMsg_Position_X - 0.358 * t13) + 0.0 * t20) +
                       -0.118 * t18) -
                      t13 * scale) +
                     t20 * absxk) +
                    t18 * 0.0;
          xyzi[i + xyzi.size(0)] =
              (((((poseMsg_Position_Y + 0.358 * t17) - 0.0 * t7) +
                 -0.118 * t8) +
                t17 * scale) -
               t7 * absxk) +
              t8 * 0.0;
          xyzi[i + xyzi.size(0) * 2] =
              (((((poseMsg_Position_Z + 0.358 * t21) + 0.0 * t19) -
                 -0.118 * t23) +
                t21 * scale) +
               t19 * absxk) -
              t23 * 0.0;
        }
        b_bundler.set_size(bundler.bundle.size(0) + xyzi.size(0), 4);
        for (i = 0; i < 4; i++) {
          m = bundler.bundle.size(0);
          for (i1 = 0; i1 < m; i1++) {
            b_bundler[i1 + b_bundler.size(0) * i] =
                bundler.bundle[i1 + bundler.bundle.size(0) * i];
          }
        }
        m = xyzi.size(0);
        for (i = 0; i < 4; i++) {
          for (i1 = 0; i1 < m; i1++) {
            b_bundler[(i1 + bundler.bundle.size(0)) + b_bundler.size(0) * i] =
                xyzi[i1 + xyzi.size(0) * i];
          }
        }
        bundler.bundle.set_size(b_bundler.size(0), 4);
        m = b_bundler.size(0) * 4;
        for (i = 0; i < m; i++) {
          bundler.bundle[i] = b_bundler[i];
        }
        //  Initial variables
        //  SET
        newSonarMsg = false;
      }
      //  Initial variables
      //  GET
      bundler.lastBundleState = bundleStarted;
      //  fprintf('INFO : proc mapping : Bundling or waiting. \n');
    }
    MATLABRate_sleep(r.RateHelper);
    coder::toc(r.PreviousPeriod.tv_sec, r.PreviousPeriod.tv_nsec);
    coder::tic(&r.PreviousPeriod.tv_sec, &r.PreviousPeriod.tv_nsec);
  }
}

// End of code generation (proc_mapping.cpp)
