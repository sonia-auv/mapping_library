//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// std_msgs_BoolStruct.h
//
// Code generation for function 'std_msgs_BoolStruct'
//

#ifndef STD_MSGS_BOOLSTRUCT_H
#define STD_MSGS_BOOLSTRUCT_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
struct std_msgs_BoolStruct_T;

// Function Declarations
std_msgs_BoolStruct_T std_msgs_BoolStruct();

#endif
// End of code generation (std_msgs_BoolStruct.h)
