//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// sensor_msgs_PointFieldStruct.h
//
// Code generation for function 'sensor_msgs_PointFieldStruct'
//

#ifndef SENSOR_MSGS_POINTFIELDSTRUCT_H
#define SENSOR_MSGS_POINTFIELDSTRUCT_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
struct sensor_msgs_PointFieldStruct_T;

// Function Declarations
void sensor_msgs_PointFieldStruct(sensor_msgs_PointFieldStruct_T *msg);

#endif
// End of code generation (sensor_msgs_PointFieldStruct.h)
