//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// sensor_msgs_PointCloud2Struct.h
//
// Code generation for function 'sensor_msgs_PointCloud2Struct'
//

#ifndef SENSOR_MSGS_POINTCLOUD2STRUCT_H
#define SENSOR_MSGS_POINTCLOUD2STRUCT_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
struct sensor_msgs_PointCloud2Struct_T;

// Function Declarations
void sensor_msgs_PointCloud2Struct(sensor_msgs_PointCloud2Struct_T *msg);

#endif
// End of code generation (sensor_msgs_PointCloud2Struct.h)
