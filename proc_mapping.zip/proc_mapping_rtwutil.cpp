//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// proc_mapping_rtwutil.cpp
//
// Code generation for function 'proc_mapping_rtwutil'
//

// Include files
#include "proc_mapping_rtwutil.h"
#include "rt_nonfinite.h"
#include <string.h>

// Function Definitions
unsigned int mul_u32_sat(unsigned int a, unsigned int b)
{
  unsigned int result;
  unsigned int u32_chi;
  mul_wide_u32(a, b, &u32_chi, &result);
  if (u32_chi) {
    result = MAX_uint32_T;
  }
  return result;
}

void mul_wide_u32(unsigned int in0, unsigned int in1,
                  unsigned int *ptrOutBitsHi, unsigned int *ptrOutBitsLo)
{
  int in0Hi;
  int in0Lo;
  int in1Hi;
  int in1Lo;
  unsigned int outBitsLo;
  unsigned int productHiLo;
  unsigned int productLoHi;
  unsigned int productLoLo;
  in0Hi = static_cast<int>(in0 >> 16U);
  in0Lo = static_cast<int>(in0 & 65535U);
  in1Hi = static_cast<int>(in1 >> 16U);
  in1Lo = static_cast<int>(in1 & 65535U);
  productHiLo = static_cast<unsigned int>(in0Hi) * in1Lo;
  productLoHi = static_cast<unsigned int>(in0Lo) * in1Hi;
  productLoLo = static_cast<unsigned int>(in0Lo) * in1Lo;
  in0Lo = 0;
  outBitsLo = productLoLo + (productLoHi << 16U);
  if (outBitsLo < productLoLo) {
    in0Lo = 1;
  }
  productLoLo = outBitsLo;
  outBitsLo += productHiLo << 16U;
  if (outBitsLo < productLoLo) {
    in0Lo = static_cast<int>(in0Lo + 1U);
  }
  *ptrOutBitsHi = ((in0Lo + static_cast<unsigned int>(in0Hi) * in1Hi) +
                   (productLoHi >> 16U)) +
                  (productHiLo >> 16U);
  *ptrOutBitsLo = outBitsLo;
}

// End of code generation (proc_mapping_rtwutil.cpp)
