//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// CoderTimeAPI.h
//
// Code generation for function 'CoderTimeAPI'
//

#ifndef CODERTIMEAPI_H
#define CODERTIMEAPI_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
void freq_not_empty_init();

#endif
// End of code generation (CoderTimeAPI.h)
