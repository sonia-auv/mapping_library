//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// proc_mapping_initialize.cpp
//
// Code generation for function 'proc_mapping_initialize'
//

// Include files
#include "proc_mapping_initialize.h"
#include "CoderTimeAPI.h"
#include "PointCloudBundler.h"
#include "proc_mapping_data.h"
#include "rt_nonfinite.h"
#include <string.h>

// Function Definitions
void proc_mapping_initialize()
{
  freq_not_empty_init();
  PointCloudBundler::persistentDataStore_init();
  isInitialized_proc_mapping = true;
}

// End of code generation (proc_mapping_initialize.cpp)
